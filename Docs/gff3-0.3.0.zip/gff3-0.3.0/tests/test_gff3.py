#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_gff3
----------------------------------

Tests for `gff3` module.
"""

import unittest

from gff3 import gff3


class TestGff3(unittest.TestCase):

    def setUp(self):
        pass

    def test_something(self):
        pass

    def tearDown(self):
        pass

if __name__ == '__main__':
    unittest.main()
