========
Usage
========

To use gff3-py in a project::

    from gff3 import Gff3

    
.. autoclass:: gff3.Gff3
   :members: