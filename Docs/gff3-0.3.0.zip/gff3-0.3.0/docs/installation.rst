============
Installation
============

At the command line::

    $ easy_install gff3

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv gff3
    $ pip install gff3
