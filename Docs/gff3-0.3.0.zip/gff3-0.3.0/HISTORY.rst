.. :changelog:

History
-------

0.3.0 (2015-03-10)
---------------------

* Fixed phase checking.

0.2.0 (2015-01-28)
---------------------

* Supports python 2.6, 2.7, 3.3, 3.4, pypy.
* Don't report empty attributes as errors.
* Improved documentation.

0.1.0 (2014-12-11)
---------------------

* First release on PyPI.
